<!-- Cover page -->

![](images/workshop_banner.png)
# MICCAI 2025 Human-AI Collaboration (HAIC) Workshop

In conjunction with the [28th International Conference on Medical Image Computing and Computer Assisted Intervention](https://conferences.miccai.org/2025/en/default.asp)

September 2025

Daejeon Convention Center, Daejeon, South Korea

[**Get Started**](README)
